* This project uses the 4 quad seven segment as a display.
* In this we can perform 4 operation +,-,*,/.
* -> This button will clear the display.
* This calculator can show result upto 9999.

