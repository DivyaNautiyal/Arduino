* In this project LCD 16x2 is used as the display.
* In this 4 operation can performed +,-,*,/ .
* This can give results up to 2,147,483,647.
